#!/usr/bin/env bash

export DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"
echo $DIR
cd $DIR
cd ..
export PYTHONPATH="$PYTHONPATH:$DIR"
export FLASK_ENV=development; env FLASK_APP=./main.py flask run

# http://127.0.0.1:5000/parse-query/Coca-Cola,%20Fanta%20or%20Sprite%20Soft%20Drink%201.25%20Litre