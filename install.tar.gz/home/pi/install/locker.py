import RPi.GPIO as GPIO
import serial
import csv

commands_db = None

with open('commands.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter='|')
    commands_db = [line for line in csv_reader]
    commands_db = {line[0]: {line[2]: line[1], line[4]: line[3]} for line in commands_db}


EN_485 = 4
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(EN_485, GPIO.OUT)
GPIO.output(EN_485, GPIO.HIGH)
t = serial.Serial("/dev/ttyS0", 9600, timeout=1)


def unlock(id):
    command = commands_db[str(id)].get('WRITE')
    hex_str = command.split(',')
    command = [int(x, 16) for x in hex_str]
    len = t.write(command)
    _str = t.readline()
    if _str:
        _str = _str[:-4]
        if not _str[-2:] == '5E':
            t.write(command)
    t.flush()


def read_status_all():
    _str = t.readall()
    return str


def read_status(pin):
    return t.readall()
