from flask import Flask, request, render_template, redirect, url_for, session, jsonify
from flask_cors import CORS, cross_origin
import sqlite3
import bcrypt
import os
from locker import unlock, read_status


SALT = '$2a$12$egOPxypQbMc3mCfRCyleE.'.encode('utf-8')


def get_db():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(BASE_DIR, "app_db.db")
    return sqlite3.connect(db_path)


app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
CORS(app)


@app.route('/')
@app.route('/index')
def index():
    return render_template('splash.html')

@app.route('/home', methods=['GET', 'POST'])
def home():
    if 'user' in session:
        if 'selected_pin' in session:
            session.pop('selected_pin')
        session.pop('user')
    if request.method == 'GET':
        return render_template('home.html', error=None)
    elif request.method == 'POST':
        pin = request.form.get('pin_field')
        if pin:
            if not len(pin) < 4 and not len(pin) > 4 and pin.isnumeric():
                hashed_pin = bcrypt.hashpw(pin.encode('utf-8'), SALT)
                conn = get_db()
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute('SELECT * FROM LOCKERS where PIN="' + hashed_pin.decode() + '"')
                rows = cur.fetchone()
                if rows:
                    read_pin = rows[1]
                    if read_pin and read_pin == hashed_pin.decode():
                        id = rows[0]
                        conn.cursor().execute('DELETE FROM LOCKERS WHERE CABINET=' + str(id))
                        conn.cursor().execute('UPDATE LOCKER_STATUS SET STATUS =' + str(0) + ' WHERE id=' + str(id))
                        conn.commit()
                        unlock(id)
                        conn.close()
                        return render_template('home.html', error='Locker %d is unlocked.' % id)
        return render_template('home.html', error="Pin doesn't exist.")


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        if 'user' in session:
            session.pop('user')
        return render_template('login.html')
    elif request.method == 'POST':
        pin = request.form.get('pin')
        if pin:
            if len(pin) == 4:
                hashed_pin = bcrypt.hashpw(pin.encode('utf-8'), SALT)
                hashed_pin = hashed_pin.decode()
                conn = get_db()
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                t = (hashed_pin, )
                cur.execute('SELECT * FROM USER where pin=?', t)
                rows = cur.fetchone()
                read_pin = rows[1]
                conn.close()
                if rows[0] == 'admin' and bcrypt.checkpw(pin.encode('utf-8'), read_pin.encode('utf-8')):
                    session['user'] = 'admin'
                    response = jsonify({'user': 'admin'})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response
                else:
                    response = jsonify({'user': None})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response
        response = jsonify({'user': None})
        response.headers.add("Access-Control-Allow-Origin", "*")
        response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
        response.headers.add("Access-Control-Allow-Headers",
                             "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
        return response


@app.route('/admin', methods=['GET'])
def admin():
    if 'user' in session:
        if 'selected_pin' in session:
            session.pop('selected_pin')
        return render_template('barebone.html', msg=None, lockers=None, mode=None)
    return render_template('login.html', error='User not logged in.')


@app.route('/insert', methods=['GET', 'POST'])
def insert_pin():
    err = 'User not logged in.'
    # if 'user' in session:
    if request.method == 'GET':
        return render_template('insert.html')
    elif request.method == 'POST':
        pin = request.form.get('pin_field')
        if pin:
            if int(pin) >= 0 and not len(pin) < 4 and not len(pin) > 4 and pin.isnumeric():
                hashed_pin = bcrypt.hashpw(pin.encode('utf-8'), SALT)
                conn = get_db()
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute('SELECT * FROM USER')
                rows = cur.fetchone()
                hashed_pin = hashed_pin.decode()
                existing_pack = conn.cursor().execute('SELECT * FROM LOCKERS where PIN="' + hashed_pin + '"').fetchone()
                read_pin = rows[1]
                conn.close()
                if bcrypt.checkpw(pin.encode('utf-8'), read_pin.encode('utf-8')) or existing_pack:
                    # if 'selected_pin' in session:
                    #     session.pop('selected_pin')

                    response = jsonify({'pin_existence': "already exists"})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response
                else:
                    response = jsonify({'new_pin': hashed_pin})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response
                    session['selected_pin'] = hashed_pin
                    return redirect(url_for('select_locker'))
            else:
                err = 'Please enter the pin.'
    response = jsonify({'no_pin': "please type the pin"})
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
    response.headers.add("Access-Control-Allow-Headers",
                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
    return response
    return render_template('login.html', error=err)


@app.route('/select-locker', methods=['GET', 'POST'])
def select_locker():
    # GET THE ROOMS ON THE PAGE
    # if 'user' in session and 'selected_pin' in session:
    if request.method == 'GET':
        conn = get_db()
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute('select * from LOCKER_STATUS')
        rows = cur.fetchall()
        conn.close()
        rooms = {}
        for row in rows:
            rooms[row[0]] = row[1]

        response = jsonify({'lockers': rooms})
        response.headers.add("Access-Control-Allow-Origin", "*")
        response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
        response.headers.add("Access-Control-Allow-Headers",
                             "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
        return response
    # SET THE PIN BY MANAGER
    elif request.method == 'POST':
        id = request.form.get('id_field')
        hashed_pin = request.form.get('hashed_pin')
        if id:
            if not len(id) < 1 and not len(id) > 2 and id.isnumeric() and not int(id) < 1 and not int(id) > 24:
                conn = get_db()
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute('SELECT * FROM LOCKER_STATUS where id=' + str(id))
                row = cur.fetchone()
                if row and row[1] == 0:
                    conn.cursor().execute('INSERT INTO LOCKERS (cabinet, pin) VALUES(' + str(id) + ',"'
                                          + hashed_pin + '")')

                    # session.pop('selected_pin')
                    conn.cursor().execute('UPDATE LOCKER_STATUS SET STATUS =' + str(1) + ' WHERE id=' + str(id))
                    conn.commit()
                    conn.close()
                    unlock(id)

                    response = jsonify({'locked_box': "ok"})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response


        return redirect(url_for('admin'))

    return redirect(url_for('login'))


@app.route('/remove-locker', methods=['GET', 'POST'])
def remove_locker():
    # REMOVE THE PIN AND BOX BY MANAGER
    # if 'user' in session:
    if request.method == 'GET':
        return render_template('barebone.html', lockers=True, mode='DEL')
    elif request.method == 'POST':
        pin = request.form.get('pin_field')
        if pin:
            if not len(pin) < 4 and not len(pin) > 4 and pin.isnumeric():
                hashed_pin = bcrypt.hashpw(pin.encode('utf-8'), SALT)
                conn = get_db()
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute('SELECT * FROM LOCKERS where pin="' + hashed_pin.decode() + '"')
                row = cur.fetchone()
                if row:
                    conn.cursor().execute('DELETE FROM LOCKERS WHERE CABINET=' + str(row[0]))
                    conn.cursor().execute('UPDATE LOCKER_STATUS SET STATUS =' + str(0) + ' WHERE id=' + str(row[0]))
                    conn.commit()
                    unlock(row[0])
                    conn.close()

                    response = jsonify({'unlocked': pin})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response
                    return render_template('barebone.html', lockers=True, mode='DEL', error="Locker %d is removed." % row[0])
                else:
                    response = jsonify({'no_such_pin': pin})
                    response.headers.add("Access-Control-Allow-Origin", "*")
                    response.headers.add("Access-Control-Request-Method", "POST, GET, OPTIONS, DELETE")
                    response.headers.add("Access-Control-Allow-Headers",
                                         "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With, enctype, filename")
                    return response
        return render_template('barebone.html', lockers=True, mode='DEL', error="Pin doesn't exist.")


    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run()
